package com.badreddin.mydiary

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: ""
        val id = intent.getStringExtra("id") ?: title
        Alarms.showNow(context, "\u23F0 $title", id.hashCode())
    }
}
