package com.badreddin.mydiary

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray

object Alarms {
    private const val PREFS = "diary"
    private const val KEY = "tasks"
    private const val CHANNEL = "tasks"
    private const val MAX_ALARMS = 400

    private fun pending(ctx: Context, id: String, title: String, flags: Int): PendingIntent? {
        val i = Intent(ctx, AlarmReceiver::class.java).putExtra("id", id).putExtra("title", title)
        return PendingIntent.getBroadcast(ctx, id.hashCode(), i, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun parse(s: String?): JSONArray =
        try { JSONArray(s ?: "[]") } catch (e: Exception) { JSONArray() }

    fun sync(ctx: Context, json: String) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        cancelAll(ctx, parse(p.getString(KEY, "[]")))
        val arr = parse(json)
        p.edit().putString(KEY, arr.toString()).apply()
        scheduleAll(ctx, arr)
    }

    fun restore(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        scheduleAll(ctx, parse(p.getString(KEY, "[]")))
    }

    private fun cancelAll(ctx: Context, arr: JSONArray) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val pi = pending(ctx, o.optString("id"), "", PendingIntent.FLAG_NO_CREATE)
            if (pi != null) {
                am.cancel(pi)
                pi.cancel()
            }
        }
    }

    private fun scheduleAll(ctx: Context, arr: JSONArray) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val items = ArrayList<Triple<String, String, Long>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val at = o.optLong("at", 0L)
            val id = o.optString("id", "")
            if (id.isEmpty() || at <= now) continue
            items.add(Triple(id, o.optString("title", ""), at))
        }
        items.sortBy { it.third }
        for (t in items.take(MAX_ALARMS)) {
            val pi = pending(ctx, t.first, t.second, PendingIntent.FLAG_UPDATE_CURRENT) ?: continue
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.third, pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.third, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.third, pi)
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun showNow(ctx: Context, text: String, nid: Int) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Tasks", NotificationManager.IMPORTANCE_HIGH)
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("My diary")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(nid, n)
        } catch (e: SecurityException) {
        }
    }
}
